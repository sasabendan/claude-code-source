# WRAP 提示文件 | v0.9 | 2026-04-24

---

## 当前状态

**主任务**：有声漫画自动化生产 Skills 体系（已完成 4 个阶段，100%）

---

## 框架完成度

### Skills（已全部实现）
- S0 task-book-keeper：加密备份 ✅
- S1 knowledge-base-manager：知识库管理 ✅
- S2 comic-style-consistency：画风一致性 ✅
- S3 audio-comic-workflow：工作流引擎 ✅
- S4 supervision-anti-drift：Supervisor + NCA + 漂移检测 ✅
- S5 self-optimizing-yield：良品率追踪 ✅

### 知识库（26 条，已索引）
- `experience/`：13 条（框架、验证、NCA、漂移、授权、流水线、良品率等）
- `styles/`：2 条（画风矩阵、多服务商 API）
- `plot/`：2 条（分镜、角色一致性）
- 另有 9 条映射到 reference 文档

---

## 待优化项目（技术债务）

| 项目 | 说明 |
|------|------|
| Rust 重写 | C1 要求新代码用 Rust，当前全为 bash/Python 脚本 |
| OpenSpec | C5 锁定 v0.21.0，当前未安装 |
| reference-04 重抓 | NCA 文章，建议从 rosetears.cn/archives/55/ 重抓 |
| Dedao/Biji API | `kb_sync_biji()` 是空 stub，需真实 API 对接 |
| Obsidian 双向链接 | vault 未初始化，双链格式未激活 |
| GitHub LLM Wiki | sdyckjq-lab/llm-wiki-skill（1067 stars）待研究集成 |

---

## 核心约束（重启必读）

1. **主任务 = 边界**：边界之外必须取得明确授权才能行动
2. **授权管理**：每日授权 + `~/.claude/authorized-scope.jsonl`
3. **Keychain**：密码存 Keychain，不写死在脚本
4. **macOS bash 3.2**：不支持 `declare -A`，中文 grep 不兼容，核心逻辑用 Python

---

## 关键文件路径

```
tasks/audio-comic-skills/
├── CLAUDE.md              ← 主入口
├── TASK_PROGRESS.md       ← 进度索引（v0.9）
├── TASK_REQUIREMENTS.md   ← 需求文档
├── master-plan.md         ← 主计划
├── knowledge-base/        ← 26 条知识（已索引）
│   └── .index.jsonl
├── reference-*.md         ← 8 个参考文献
└── backups/
    ├── backup_20260424_215619.tar.gz   ← 项目备份
    └── skills_backup_20260424_215619.tar.gz  ← Skills 备份

~/.claude/
├── memory-store.jsonl     ← 启动自提醒（含 wrap-prep-20260424）
└── authorized-scope.jsonl ← 授权记录

skills/
├── task-book-keeper/      ← S0 备份
├── knowledge-base-manager/ ← S1 知识库
├── comic-style-consistency/ ← S2 画风
├── audio-comic-workflow/   ← S3 工作流
├── supervision-anti-drift/ ← S4 Supervisor
└── self-optimizing-yield/  ← S5 良品率
```

---

## 参考文献状态（v0.9）

| 文件 | 状态 |
|------|------|
| reference-01 | ✅ 清洗完成（2509 行，移除 HTML 垃圾） |
| reference-02 | ✅ 重写完成（Get 笔记 API 参考，URL 变更后手动整理） |
| reference-03 | ✅ 清洗完成（rosetears Supervisor-Worker） |
| reference-04 | ⚠️ 需重抓（NCA 文章，建议从 rosetears.cn 重抓） |
| reference-05 | ✅ 完整（baoyu-skills 53KB） |
| reference-06（naruto） | ✅ 完整 |
| reference-06（openspec） | ✅ 清洗完成 |
| reference-07 | ✅ 完整（Comic Creator Skill） |

---

## Wrap 前最后工作清单

- [x] 备份项目（tar.gz）
- [x] 备份 skills（tar.gz）
- [x] 写入启动自提醒（memory-store.jsonl）
- [x] 更新 TASK_PROGRESS.md（v0.9）
- [x] 清洗 reference-01/02
- [x] 写 WRAP.md（本文件）
- [ ] 最终备份（含 WRAP.md）

---

## 重启后第一个动作

读取 WRAP.md，然后读取 CLAUDE.md，确认边界后开始工作。
不要在未读 WRAP.md 的情况下做任何涉及边界的操作。
