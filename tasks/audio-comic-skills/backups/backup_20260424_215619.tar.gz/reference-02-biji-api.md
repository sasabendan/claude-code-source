 个人知识库 | Get笔记使用文档
	window.StarlightThemeProvider = (() => {
		const storedTheme =
			typeof localStorage !== 'undefined' && localStorage.getItem('starlight-theme');
		const theme =
			storedTheme ||
			(window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
		document.documentElement.dataset.theme = theme === 'light' ? 'light' : 'dark';
		return {
			updatePickers(theme = storedTheme || 'auto') {
				document.querySelectorAll('starlight-theme-select').forEach((picker) => {
					const select = picker.querySelector('select');
					if (select) select.value = theme;
					/** @type {HTMLTemplateElement | null} */
					const tmpl = document.querySelector(`#theme-icons`);
					const newIcon = tmpl && tmpl.content.querySelector('.' + theme);
					if (newIcon) {
						const oldIcon = picker.querySelector('svg.label-icon');
						if (oldIcon) {
							oldIcon.replaceChildren(...newIcon.cloneNode(true).childNodes);
						}
					}
				});
			},
		};
	})();
     跳转到内容          Get笔记使用文档          搜索  CtrlK       取消         
	(() => {
		const openBtn = document.querySelector('button[data-open-modal]');
		const shortcut = openBtn?.querySelector('kbd');
		if (!openBtn || !(shortcut instanceof HTMLElement)) return;
		const platformKey = shortcut.querySelector('kbd');
		if (platformKey && /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform)) {
			platformKey.textContent = '⌘';
			openBtn.setAttribute('aria-keyshortcuts', 'Meta+K');
		}
		shortcut.style.display = '';
	})();
            选择主题    深色浅色自动        
	StarlightThemeProvider.updatePickers();
 const r="starlight-theme",o=e=>e==="auto"||e==="dark"||e==="light"?e:"auto",c=()=>o(typeof localStoragematchMedia("(prefers-color-scheme: light)").matches?"light":"dark";function t(e){StarlightThemeProvider.updatePickers(e),document.documentElement.dataset.theme=e==="auto"?l():e,n(e)}matchMedia("(prefers-color-scheme: light)").addEventListener("change",()=>{c()==="auto"&&t("auto")});class s extends HTMLElement{constructor(){super(),t(c()),this.querySelector("select")?.addEventListener("change",a=>{a.currentTarget instanceof HTMLSelectElement&&t(o(a.currentTarget.value))})}}customElements.define("starlight-theme-select",s); class s extends HTMLElement{constructor(){super();const e=this.querySelector("select");e&&(e.addEventListener("change",t=>{t.currentTarget instanceof HTMLSelectElement&&(window.location.pathname=t.currentTarget.value)}),window.addEventListener("pageshow",t=>{if(!t.persisted)return;const n=e.querySelector("option[selected]")?.index;n!==e.selectedIndex&&(e.selectedIndex=n??0)}))}}customElements.define("starlight-lang-select",s);           class s extends HTMLElement{constructor(){super(),this.btn=this.querySelector("button"),this.btn.addEventListener("click",()=>this.toggleExpanded());const t=this.closest("nav");t&&t.addEventListener("keyup",e=>this.closeOnEscape(e))}setExpanded(t){this.setAttribute("aria-expanded",String(t)),document.body.toggleAttribute("data-mobile-menu-expanded",t)}toggleExpanded(){this.setExpanded(this.getAttribute("aria-expanded")!=="true")}closeOnEscape(t){t.code==="Escape"&&(this.setExpanded(!1),this.btn.focus())}}customElements.define("starlight-menu-button",s);        Hi，欢迎来到 Get 笔记        如何快速上手记笔记         APP下载与使用     录音润色-懒得打字？说出来就行！     线下会议录音-高效记录会议     课堂录音-秒出学霸笔记     链接一键记-精华总结     拍几张照-秒变笔记     手机内录-边听边记       导入音视频-收获精华笔记         iOS语音备忘录等APP中音频如何导入Get笔记？         智能拍书-纸质书笔记永不丢失     声纹识别—让 AI 认识你的声音      语音口令—说话就能划重点     语音词库-录音识别更精准     桌面小组件-一键直达     Siri 唤起-解放双手     快捷指令-效率翻倍     微信小程序-随手记录     网页端-大屏浏览           Get笔记知识库         创建知识库       帮你听直播         如何找到得到 APP 的直播链接？           订阅短视频博主         如何找到抖音博主名片链接？         上传文件     分享和团队管理     将已有笔记加入知识库     Get笔记知识库API           GetSeed AI录音卡         快速使用     功能说明     笔记发芽     AI柳比歇夫记日记     设备指南     常见问题           产品更新说明         iOS     Android     HarmonyOS      桌面端 MacOS         即将推出       最佳实践-原来还能这么用         原来还能这么用！Get笔记最佳实践案例-更新中     基于「得到App」提问，快速写稿     律师用Get笔记搭建知识库，应对重复性咨询问题     丝滑创作小红书、小绿书爆款文案           Get达人们这么说         王树义老师：得到 Get 笔记 AI 手机应用，好用吗？     曹将：看完罗振宇跨年演讲，种草了一个软件     系统飞轮：看完罗振宇跨年演讲，种草了一个笔记软件     暮野之月：得到出品的Get笔记App来了，免费版已够用      问问AI提示词写作：“Get笔记：打造你的&#39;第二大脑&#39;，简化记忆与学习”     此木羊：Get笔记体验报告：重构知识管理三要素，实现Flomo灵感流+Cubox收藏术+Deepseek脑库的智能进化     飞掣有术：当DeepSeek与Get笔记结合在一起，教育创业者工作流翻倍提升     曹将：DeepSeek卡顿时，这个APP救了我     秋叶PPT：分享1个让效率爆涨的AI神器，真后悔我没早点用上！           常见问题         如何换绑手机号？     个人知识库         联系我们       Get笔记AI技能和开放平台           Skill 使用指南         开放平台和AI技能         CLI 使用指南     MCP 使用指南     API 文档            -->       const a=document.getElementById("starlight__sidebar"),n=a?.querySelector("sl-sidebar-state-persist"),o="sl-sidebar-state",i=()=>{let t=[];const e=n?.dataset.hash||"";try{const s=sessionStorage.getItem(o),r=JSON.parse(s||"{}");Array.isArray(r.open)&&r.hash===e&&(t=r.open)}catch{}return{hash:e,open:t,scroll:a?.scrollTop||0}},c=t=>{try{sessionStorage.setItem(o,JSON.stringify(t))}catch{}},d=()=>c(i()),l=(t,e)=>{const s=i();s.open[e]=t,c(s)};n?.addEventListener("click",t=>{if(!(t.target instanceof Element))return;const e=t.target.closest("summary")?.closest("details");if(!e)return;const s=e.querySelector("sl-sidebar-restore"),r=parseInt(s?.dataset.index||"");isNaN(r)||l(!e.open,r)});addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"&&d()});addEventListener("pageHide",d);    本页内容    概述     本页内容   概述                个人知识库        
    一句话理解什么是知识库？
        可以简单的理解为是一种更高级的笔记整理分类和再创作。
        用户可以新建不同的个人专题知识库，知识库里可以导入自己的笔记和文件，关注不同的博主和直播，最终可以结合这些专题知识库进行搜索、提问、二创等，未来也会加入团队的知识库协作。
        在强大AI模型的支持下，个人或团队可以通过知识库更高效地管理和使用自己的知识资产。
    如何创建个人知识库？
        从 APP 首页顶部“更多”入口进入
        点击知识库页面右上角“+新建”按钮
        创建后，即可在知识库中上传文件、订阅直播、订阅博主或添加已有笔记
        可以编辑知识库名称、描述，如果删除知识库，则知识库及其中的文件内容也会一并删除，请谨慎操作
    怎么让 AI 帮我听直播讲座？
        个人知识库支持订阅得到直播和视频号直播。只需上传直播链接或预约截图，系统会自动为你生成直播重点内容纪要。
    视频号短视频是否可以自动生成笔记？
        单个视频号短视频由于没有可对外分享的链接，所以无法通过链接的形式交给Get笔记处理。
目前个人知识库中，通过订阅指定视频号，可以自动获取和整理该视频号下更新的内容。
     怎么把自己关注的抖音号、视频号扔给 Get 笔记？
        在个人知识库中添加内容，点击“订阅直播/博主”:
          抖音博主：粘贴个人主页链接
          视频号：上传视频号博主主页截图
    Get笔记对于直播或者回放的处理效果为什么会不同?
        Get笔记对于直播的处理，使用了两套不同的AI处理模板:
          个人知识库: 采用类似罗老师学习笔记的专业模板
          普通链接识别：使用的是通用链接笔记处理模板，接下来会对直播回放链接采用上述专业模版进行处理
        备注：所有内容都由AI处理，只是使用了不同的处理模板，因此生成的笔记效果会有差异。
    可以上传文件吗？
        个人知识库支持了PDF、Word、PPT格式的文件上传，单个文件不超过 200M。
    知识库的容量有多少？
        每个用户可免费创建 3个知识库，空间共30G（10G/个）
        PRO会员可创建 10个知识库，空间共500G（50G/个）
    是否需要会员？会员和非会员有什么区别吗？是付费的吗？
        会员和非会员均可使用，目前还没有完全确定付费模式，我们会在后续版本中公布详细的会员权益，但「所有用户都能体验完整的 AI 能力，会员与免费用户的区别，仅限于使用次数/容量上的不同。」
