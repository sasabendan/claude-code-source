---
name: audio-comic-production
description: 有声漫画自动化生产 Skills 体系主入口。触发词"开始创作有声漫画"后自动完成全流程。
---

# 有声漫画自动化生产 Skills 体系

## 项目概述
- **核心场景**：输入原著文本（小说），输出有声漫画产品
- **触发词**：`开始创作有声漫画`

## Skills 架构
- **S1** knowledge-base-manager：知识库管理
- **S2** comic-style-consistency：风格锚定
- **S3** audio-comic-workflow：流水线编排
- **S4** supervision-anti-drift：监督验收
- **S5** self-optimizing-yield：良品率优化
- **S0** task-book-keeper：任务书管理

## 关键知识库位置

### 项目知识库（内置）
```
knowledge-base/              # 本项目知识库
knowledge-base/.index.jsonl  # 索引
knowledge-base/experience/   # 经验知识（含参考文献映射）
```

### 参考文献
| 文件 | 内容 |
|------|------|
| `reference-03-rosetears-85.md` | rosetears Supervisor-Worker 框架原文 |
| `reference-06-openspec-630.md` | OpenSpec v0.21.0 vs v1.0 GitHub Issue |

### 下载资源（原始文件）
原始 OpenSpec/Codex/Supervisor 框架资源：
```
/Users/jennyhu/Documents/Claude code - openspec - codex(1)/
```
详情见知识库：`knowledge-base/experience/下载文件_如何使用_md.md`

## OpenSpec/Codex Supervisor 框架
本项目整合了 rosetears Supervisor-Worker 框架用于任务监督验收：
- Supervisor = Claude Code（验收确权）
- Worker = Codex（执行实现）
- 三记忆文件：`tasks.md`、`progress.txt`、`feature_list.json`
- 详情：`knowledge-base/experience/rosetears_supervisor_framework.md`

## 授权管理
- 当前授权范围：见 `~/.claude/authorized-scope.jsonl`
- 每日打卡：主任务未完成前，每天向用户确认授权
- 核心原则：主任务 = 边界，边界之外必须取得明确授权
